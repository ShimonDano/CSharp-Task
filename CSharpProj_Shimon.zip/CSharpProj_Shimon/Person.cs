﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpProj_Shimon
{
    class Person
    {
        protected string Fname;
        protected string Lname;
        protected int id;
    }
}
